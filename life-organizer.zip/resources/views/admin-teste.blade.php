<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Área Administrativa</title>
</head>
<body>
    <h1>Bem-vindo, administrador!</h1>
    <p>Você está acessando uma página restrita apenas para administradores.</p>
</body>
</html> 