<style>
.status-dot {
  display: inline-block;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  margin-right: 6px;
  vertical-align: middle;
}
.status-todo { background: #a3a3a3; }         /* cinza */
.status-in_progress { background: #facc15; }  /* amarelo */
.status-paused { background: #fb923c; }       /* laranja */
.status-completed { background: #22c55e; }    /* verde */
.status-canceled { background: #ef4444; }     /* vermelho */
</style>
