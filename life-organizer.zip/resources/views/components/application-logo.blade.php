<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" {{ $attributes }}>
  <rect width="48" height="48" rx="12" fill="#1e293b"/>
  <rect x="12" y="28" width="4" height="8" rx="2" fill="#38bdf8"/>
  <rect x="20" y="20" width="4" height="16" rx="2" fill="#38bdf8"/>
  <rect x="28" y="12" width="4" height="24" rx="2" fill="#38bdf8"/>
  <rect x="36" y="24" width="4" height="12" rx="2" fill="#38bdf8"/>
  <circle cx="24" cy="24" r="23" stroke="#38bdf8" stroke-width="2"/>
</svg>
