<div class="w-full max-w-7xl mx-auto px-1.5 sm:px-6 lg:px-8 min-w-0">
    <div class="bg-white dark:bg-gray-900 rounded-xl shadow-lg border border-gray-200 dark:border-gray-800 p-4 sm:p-6">
        <h1 class="text-lg sm:text-2xl font-bold mb-4">Clientes</h1>
        <div class="overflow-x-auto w-full">
            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-800">
                <!-- ... cabeçalho e corpo da tabela ... -->
            </table>
        </div>
    </div>
</div> 