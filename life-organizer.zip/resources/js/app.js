import './bootstrap';

import Alpine from 'alpinejs';

import './frase-motivacional';

window.Alpine = Alpine;

Alpine.start();
